from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import RegisterForm
from documents.models import Document, AIRequest

def home_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'home.html')

def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f"Welcome to MULTIDOC-AI, {user.username}! Account created successfully.")
            return redirect('dashboard')
        else:
            messages.error(request, "Registration failed. Please check the errors below.")
    else:
        form = RegisterForm()
    return render(request, 'auth/register.html', {'form': form})

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f"Welcome back, {user.username}!")
            return redirect('dashboard')
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    return render(request, 'auth/login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('home')

@login_required
def dashboard_view(request):
    user = request.user
    documents = Document.objects.filter(user=user)
    recent_documents = documents[:5]
    recent_queries = AIRequest.objects.filter(user=user)[:5]

    total_docs = documents.count()
    total_words = sum(d.word_count for d in documents)
    total_ai_requests = AIRequest.objects.filter(user=user).count()

    context = {
        'total_docs': total_docs,
        'total_words': total_words,
        'total_ai_requests': total_ai_requests,
        'recent_documents': recent_documents,
        'recent_queries': recent_queries,
    }
    return render(request, 'dashboard.html', context)

@login_required
def settings_view(request):
    user = request.user
    user_docs = Document.objects.filter(user=user)
    
    if request.method == 'POST':
        api_key = request.POST.get('api_key', '').strip()
        # Note: API Key can be saved to session or user profile if desired
        if api_key:
            request.session['user_api_key'] = api_key
            messages.success(request, "Custom AI API Key saved for this session!")
        else:
            request.session.pop('user_api_key', None)
            messages.info(request, "Using default/environment AI configuration.")
        return redirect('settings')

    context = {
        'user': user,
        'total_docs': user_docs.count(),
        'total_words': sum(d.word_count for d in user_docs),
        'session_api_key': request.session.get('user_api_key', ''),
    }
    return render(request, 'settings.html', context)
