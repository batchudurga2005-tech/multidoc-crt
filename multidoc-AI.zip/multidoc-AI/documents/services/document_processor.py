import os
import re
from pypdf import PdfReader
from docx import Document as DocxDocument
from django.utils import timezone
from ..models import Document, DocumentContent

ALLOWED_EXTENSIONS = {'pdf', 'docx', 'txt'}
MAX_FILE_SIZE = 15 * 1024 * 1024  # 15 MB limit

def validate_uploaded_file(uploaded_file):
    """
    Validates uploaded file extension and size.
    Returns (is_valid, error_message, file_ext)
    """
    if not uploaded_file:
        return False, "No file uploaded.", ""

    ext = os.path.splitext(uploaded_file.name)[1].lower().replace('.', '')
    if ext not in ALLOWED_EXTENSIONS:
        return False, f"Unsupported file extension '.{ext}'. Allowed types: PDF, DOCX, TXT.", ext

    if uploaded_file.size > MAX_FILE_SIZE:
        return False, f"File size exceeds limit of 15MB. (File size: {uploaded_file.size / (1024*1024):.1f}MB)", ext

    return True, "", ext


def process_document(document_instance):
    """
    Processes a Document model instance: reads PDF, DOCX, or TXT text,
    stores extracted text, updates word count and processing status.
    """
    try:
        document_instance.processing_status = 'processing'
        document_instance.save(update_fields=['processing_status'])

        file_path = document_instance.file.path
        ext = document_instance.file_type.lower()
        extracted_text = ""

        if ext == 'pdf':
            reader = PdfReader(file_path)
            pages_text = []
            for idx, page in enumerate(reader.pages):
                text = page.extract_text()
                if text:
                    pages_text.append(text)
            extracted_text = "\n\n".join(pages_text)

        elif ext == 'docx':
            doc = DocxDocument(file_path)
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            # Also read tables
            for table in doc.tables:
                for row in table.rows:
                    row_text = " | ".join([cell.text.strip() for cell in row.cells if cell.text.strip()])
                    if row_text:
                        paragraphs.append(row_text)
            extracted_text = "\n".join(paragraphs)

        elif ext == 'txt':
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                extracted_text = f.read()

        else:
            raise ValueError(f"Unsupported file type: {ext}")

        extracted_text = extracted_text.strip()

        if not extracted_text:
            document_instance.processing_status = 'failed'
            document_instance.error_message = "Document is empty or text could not be extracted."
            document_instance.save(update_fields=['processing_status', 'error_message'])
            return False

        # Clean text
        cleaned_text = re.sub(r'\s+', ' ', extracted_text).strip()
        words = cleaned_text.split()
        word_count = len(words)

        document_instance.extracted_text = extracted_text
        document_instance.word_count = word_count
        document_instance.processing_status = 'processed'
        document_instance.error_message = ''
        document_instance.save(update_fields=['extracted_text', 'word_count', 'processing_status', 'error_message'])

        # Store or update DocumentContent model
        DocumentContent.objects.update_or_create(
            document=document_instance,
            defaults={
                'raw_text': extracted_text,
                'cleaned_text': cleaned_text
            }
        )

        return True

    except Exception as e:
        document_instance.processing_status = 'failed'
        document_instance.error_message = f"Failed to process document: {str(e)}"
        document_instance.save(update_fields=['processing_status', 'error_message'])
        return False
