from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.db.models import Q
import os

from .models import Document, DocumentContent
from .forms import DocumentUploadForm
from .services.document_processor import validate_uploaded_file, process_document
from .services import ai_service

@login_required
def upload_view(request):
    if request.method == 'POST':
        files = request.FILES.getlist('files')
        if not files:
            messages.error(request, "Please select at least one document file to upload.")
            return redirect('upload')

        uploaded_count = 0
        failed_count = 0

        for f in files:
            is_valid, err_msg, ext = validate_uploaded_file(f)
            if not is_valid:
                messages.error(request, f"Error with file '{f.name}': {err_msg}")
                failed_count += 1
                continue

            doc = Document.objects.create(
                user=request.user,
                file=f,
                filename=f.name,
                file_type=ext,
                file_size=f.size,
                processing_status='pending'
            )

            # Process document text extraction immediately
            success = process_document(doc)
            if success:
                uploaded_count += 1
            else:
                failed_count += 1

        if uploaded_count > 0:
            messages.success(request, f"Successfully uploaded and processed {uploaded_count} document(s)!")
        if failed_count > 0:
            messages.warning(request, f"{failed_count} file(s) failed processing or contained errors.")

        return redirect('my_documents')

    form = DocumentUploadForm()
    recent_uploads = Document.objects.filter(user=request.user)[:5]
    return render(request, 'documents/upload.html', {'form': form, 'recent_uploads': recent_uploads})


@login_required
def my_documents_view(request):
    query = request.GET.get('q', '').strip()
    file_type = request.GET.get('type', '').strip()

    documents = Document.objects.filter(user=request.user)

    if query:
        documents = documents.filter(Q(filename__icontains=query) | Q(extracted_text__icontains=query))
    if file_type:
        documents = documents.filter(file_type=file_type)

    context = {
        'documents': documents,
        'query': query,
        'selected_type': file_type,
        'total_count': documents.count(),
    }
    return render(request, 'documents/library.html', context)


@login_required
def document_preview_api(request, doc_id):
    """API endpoint to get document details and preview text."""
    doc = get_object_or_404(Document, id=doc_id, user=request.user)
    return JsonResponse({
        'id': doc.id,
        'filename': doc.filename,
        'file_type': doc.file_type.upper(),
        'file_size': doc.file_size_formatted(),
        'uploaded_at': doc.uploaded_at.strftime('%B %d, %Y %H:%M'),
        'word_count': doc.word_count,
        'status': doc.processing_status,
        'text': doc.extracted_text[:5000] if doc.extracted_text else "No text extracted.",
        'error': doc.error_message
    })


@login_required
def delete_document_view(request, doc_id):
    if request.method == 'POST':
        doc = get_object_or_404(Document, id=doc_id, user=request.user)
        filename = doc.filename
        if doc.file:
            if os.path.exists(doc.file.path):
                try:
                    os.remove(doc.file.path)
                except Exception:
                    pass
        doc.delete()
        messages.success(request, f"Document '{filename}' was deleted successfully.")
    return redirect('my_documents')


@login_required
def summarize_view(request):
    user_docs = Document.objects.filter(user=request.user, processing_status='processed')
    result = None

    if request.method == 'POST':
        selected_doc_ids = request.POST.getlist('doc_ids')
        summary_type = request.POST.get('summary_type', 'detailed')

        if not selected_doc_ids:
            messages.error(request, "Please select at least one document to summarize.")
        else:
            selected_docs = user_docs.filter(id__in=selected_doc_ids)
            result = ai_service.summarize_document(request.user, selected_docs, summary_type=summary_type)
            result['summary_type'] = summary_type
            result['doc_names'] = [d.filename for d in selected_docs]

    context = {
        'documents': user_docs,
        'result': result
    }
    return render(request, 'documents/summarize.html', context)


@login_required
def compare_view(request):
    user_docs = Document.objects.filter(user=request.user, processing_status='processed')
    result = None

    if request.method == 'POST':
        selected_doc_ids = request.POST.getlist('doc_ids')
        if len(selected_doc_ids) < 2:
            messages.error(request, "Please select at least two documents for comparison.")
        else:
            selected_docs = user_docs.filter(id__in=selected_doc_ids)
            result = ai_service.compare_documents(request.user, selected_docs)
            result['selected_docs'] = selected_docs

    context = {
        'documents': user_docs,
        'result': result
    }
    return render(request, 'documents/compare.html', context)


@login_required
def extract_view(request):
    user_docs = Document.objects.filter(user=request.user, processing_status='processed')
    result = None

    if request.method == 'POST':
        selected_doc_ids = request.POST.getlist('doc_ids')
        if not selected_doc_ids:
            messages.error(request, "Please select at least one document to extract information from.")
        else:
            selected_docs = user_docs.filter(id__in=selected_doc_ids)
            result = ai_service.extract_information(request.user, selected_docs)
            result['doc_names'] = [d.filename for d in selected_docs]

    context = {
        'documents': user_docs,
        'result': result
    }
    return render(request, 'documents/extract.html', context)
