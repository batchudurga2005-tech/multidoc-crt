from django.db import models
from django.contrib.auth.models import User
import os

class Document(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('processed', 'Processed'),
        ('failed', 'Failed'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='documents')
    file = models.FileField(upload_to='user_documents/')
    filename = models.CharField(max_length=255)
    file_type = models.CharField(max_length=20) # pdf, docx, txt
    file_size = models.BigIntegerField() # bytes
    uploaded_at = models.DateTimeField(auto_now_add=True)
    processing_status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    extracted_text = models.TextField(blank=True, default='')
    word_count = models.IntegerField(default=0)
    error_message = models.TextField(blank=True, default='')

    class Meta:
        ordering = ['-uploaded_at']

    def __str__(self):
        return f"{self.filename} ({self.user.username})"

    def file_size_formatted(self):
        size = self.file_size
        if size < 1024:
            return f"{size} B"
        elif size < 1024 * 1024:
            return f"{size / 1024:.1f} KB"
        else:
            return f"{size / (1024 * 1024):.2f} MB"

    def extension_upper(self):
        return self.file_type.upper()


class DocumentContent(models.Model):
    document = models.OneToOneField(Document, on_delete=models.CASCADE, related_name='content')
    raw_text = models.TextField()
    cleaned_text = models.TextField(blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Content for {self.document.filename}"


class AIRequest(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='ai_requests')
    request_type = models.CharField(max_length=50) # 'ask', 'summarize', 'compare', 'extract'
    prompt_summary = models.TextField(blank=True, default='')
    tokens_used = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, default='success')

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.request_type.upper()} by {self.user.username} at {self.created_at.strftime('%Y-%m-%d %H:%M')}"
