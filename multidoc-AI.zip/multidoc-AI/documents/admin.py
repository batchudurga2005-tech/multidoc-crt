from django.contrib import admin
from .models import Document, DocumentContent, AIRequest

@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display = ('filename', 'user', 'file_type', 'file_size_formatted', 'word_count', 'processing_status', 'uploaded_at')
    list_filter = ('file_type', 'processing_status', 'uploaded_at')
    search_fields = ('filename', 'extracted_text', 'user__username')
    readonly_fields = ('uploaded_at', 'word_count')

@admin.register(DocumentContent)
class DocumentContentAdmin(admin.ModelAdmin):
    list_display = ('document', 'created_at')
    search_fields = ('document__filename', 'raw_text')

@admin.register(AIRequest)
class AIRequestAdmin(admin.ModelAdmin):
    list_display = ('request_type', 'user', 'prompt_summary', 'tokens_used', 'status', 'created_at')
    list_filter = ('request_type', 'status', 'created_at')
    search_fields = ('prompt_summary', 'user__username')
