from django.urls import path
from . import views

urlpatterns = [
    path('upload/', views.upload_view, name='upload'),
    path('library/', views.my_documents_view, name='my_documents'),
    path('api/preview/<int:doc_id>/', views.document_preview_api, name='document_preview'),
    path('delete/<int:doc_id>/', views.delete_document_view, name='delete_document'),
    path('summarize/', views.summarize_view, name='summarize'),
    path('compare/', views.compare_view, name='compare'),
    path('extract/', views.extract_view, name='extract'),
]
