/* ==========================================================================
   MULTIDOC-AI Application Core JavaScript
   ========================================================================== */

document.addEventListener('DOMContentLoaded', function() {
    
    // Auto-dismiss Django Messages after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Drag and Drop Upload Handler
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('fileInput');
    const selectedFilesList = document.getElementById('selectedFilesList');

    if (dropzone && fileInput) {
        ['dragenter', 'dragover'].forEach(eventName => {
            dropzone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropzone.classList.add('dragover');
            }, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropzone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropzone.classList.remove('dragover');
            }, false);
        });

        dropzone.addEventListener('drop', (e) => {
            const dt = e.dataTransfer;
            const files = dt.files;
            fileInput.files = files;
            updateSelectedFilesUI(files);
        });

        fileInput.addEventListener('change', (e) => {
            updateSelectedFilesUI(fileInput.files);
        });
    }

    function updateSelectedFilesUI(files) {
        if (!selectedFilesList) return;
        selectedFilesList.innerHTML = '';
        if (files.length === 0) return;

        let html = '<ul class="list-group list-group-flush bg-transparent mt-3">';
        for (let i = 0; i < files.length; i++) {
            const f = files[i];
            const sizeMB = (f.size / (1024 * 1024)).toFixed(2);
            html += `
                <li class="list-group-item bg-transparent text-light border-secondary d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fa-solid fa-file-lines text-info me-2"></i>
                        <strong>${f.name}</strong>
                    </div>
                    <span class="badge bg-dark border border-secondary">${sizeMB} MB</span>
                </li>
            `;
        }
        html += '</ul>';
        selectedFilesList.innerHTML = html;
    }

});

// Helper Function to Copy Text to Clipboard
function copyToClipboard(elementId) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const text = el.innerText || el.textContent;
    navigator.clipboard.writeText(text).then(() => {
        showToast('Success', 'Copied content to clipboard!');
    }).catch(err => {
        console.error('Failed to copy: ', err);
    });
}

// Helper Function to Download Text as File
function downloadTextAsFile(elementId, filename = 'summary.txt') {
    const el = document.getElementById(elementId);
    if (!el) return;
    const text = el.innerText || el.textContent;
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Global Toast Messenger
function showToast(title, message) {
    const toastContainer = document.getElementById('toastContainer');
    if (!toastContainer) return;

    const toastEl = document.createElement('div');
    toastEl.className = 'toast align-items-center text-bg-dark border-primary show mb-2';
    toastEl.setAttribute('role', 'alert');
    toastEl.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                <strong class="text-info me-2"><i class="fa-solid fa-circle-check"></i> ${title}:</strong> ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    toastContainer.appendChild(toastEl);
    setTimeout(() => {
        toastEl.remove();
    }, 4000);
}
