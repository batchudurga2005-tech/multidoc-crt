from django.urls import path
from . import views

urlpatterns = [
    path('ask/', views.ask_ai_view, name='ask_ai'),
    path('api/send/', views.api_send_message, name='api_send_message'),
    path('api/clear/', views.api_clear_chat, name='api_clear_chat'),
]
