from django.contrib import admin
from .models import ChatSession, ChatMessage

@admin.register(ChatSession)
class ChatSessionAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'created_at', 'updated_at')
    search_fields = ('title', 'user__username')

@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ('sender', 'user', 'short_question', 'timestamp')
    search_fields = ('question', 'response', 'user__username')

    def short_question(self, obj):
        return obj.question[:50] if obj.question else "AI Response"
    short_question.short_description = "Question"
