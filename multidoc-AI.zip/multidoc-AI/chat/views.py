import json
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from documents.models import Document
from documents.services import ai_service
from .models import ChatSession, ChatMessage

@login_required
def ask_ai_view(request):
    user = request.user
    user_docs = Document.objects.filter(user=user, processing_status='processed')
    
    # Get or create default session
    session_id = request.GET.get('session_id')
    if session_id:
        session = get_object_or_404(ChatSession, id=session_id, user=user)
    else:
        session = ChatSession.objects.filter(user=user).first()
        if not session:
            session = ChatSession.objects.create(user=user, title="Multi-Doc Assistant Chat")

    chat_messages = session.messages.all() if session else []

    context = {
        'documents': user_docs,
        'session': session,
        'chat_messages': chat_messages,
    }
    return render(request, 'chat/ask_ai.html', context)


@login_required
def api_send_message(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'POST request required.'}, status=400)

    try:
        data = json.loads(request.body)
        question = data.get('question', '').strip()
        doc_ids = data.get('doc_ids', [])
        session_id = data.get('session_id')

        if not question:
            return JsonResponse({'error': 'Question cannot be empty.'}, status=400)

        user = request.user
        if session_id:
            session = get_object_or_404(ChatSession, id=session_id, user=user)
        else:
            session = ChatSession.objects.create(user=user, title=f"Chat ({question[:30]}...)")

        # Get target documents
        user_docs = Document.objects.filter(user=user, processing_status='processed')
        if doc_ids:
            selected_docs = user_docs.filter(id__in=doc_ids)
        else:
            selected_docs = user_docs

        if not selected_docs.exists():
            return JsonResponse({
                'error': 'No processed documents available. Please upload documents first.'
            }, status=400)

        # Call AI Service
        ai_result = ai_service.ask_question(user, selected_docs, question)
        answer = ai_result.get('answer', '')
        sources = ai_result.get('sources', [])

        # Save ChatMessage
        msg = ChatMessage.objects.create(
            session=session,
            user=user,
            sender='ai',
            question=question,
            response=answer
        )
        msg.source_documents.set(selected_docs)

        return JsonResponse({
            'success': True,
            'question': question,
            'answer': answer,
            'sources': sources,
            'used_api': ai_result.get('used_api', False),
            'timestamp': msg.timestamp.strftime('%H:%M:%S')
        })

    except Exception as e:
        return JsonResponse({'error': f"Failed to process query: {str(e)}"}, status=500)


@login_required
def api_clear_chat(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            session_id = data.get('session_id')
            if session_id:
                session = ChatSession.objects.filter(id=session_id, user=request.user).first()
                if session:
                    session.messages.all().delete()
            else:
                ChatMessage.objects.filter(user=request.user).delete()
            return JsonResponse({'success': True})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    return JsonResponse({'error': 'POST request required'}, status=400)
